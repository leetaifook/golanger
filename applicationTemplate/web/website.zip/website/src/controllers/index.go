package controllers

import (
	"fmt"
	"net/http"
	"time"
)

type PageIndex struct {
	Application
}

func init() {
	App.RegisterController("index/", PageIndex{})
}

// route => , index, index/, index/index
func (p *PageIndex) Index() {
	p.RW.Write([]byte("hello world, welcome to access " + p.R.URL.String()))
}

// route => write, index/write
func (p *PageIndex) Write(w http.ResponseWriter) {
	w.Write([]byte("hello world"))
}

// route => request, index/request
func (p *PageIndex) Request(r *http.Request) {
	fmt.Println(r.URL)
}

// route => write_request, index/write_request
func (p *PageIndex) WriteRequest(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte(r.URL.String()))
}

func (p *PageIndex) Test() {
	p.RW.Write([]byte("test1"))
	d, _ := time.ParseDuration("10s")
	time.Sleep(d)
	p.RW.Write([]byte("test2"))
}

package models

/*import (
    "golanger.com/utils"
)

var (
    ColTableName = utils.M{
        "name":  "table_name",
        "index": []string{"domain", "table", "key", "time"},
    }
)

/ *测试表
table_name
{
    "table" : <table>,
    "key" : <key>,
    "expires" : <expires>,
    "time" : <time>
}
* /

type ModelTableName struct {
    Table   string
    Key     string
    Expires int
    Time    int64
}
*/
